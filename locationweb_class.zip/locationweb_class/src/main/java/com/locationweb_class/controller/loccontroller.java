package com.locationweb_class.controller;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.locationweb_class.dto.locdto;
import com.locationweb_class.entity.loc;
import com.locationweb_class.services.locservices;

@Controller
public class loccontroller {
	
	@Autowired
	private locservices locserv;
	@RequestMapping("/locc")
	public String alllocation(ModelMap modelmap){
		List<loc>locweb= locserv.getalllocation();
		modelmap.addAttribute("locweb",locweb);
		return "showlocation";
	}
	@RequestMapping("/locdata")
	public String writeloc(@ModelAttribute("loc")loc loc,ModelMap modelmap) {
		locserv.insertlocation(loc);	
		List<loc>locweb= locserv.getalllocation();
		modelmap.addAttribute("locweb",locweb);	
		return "showlocation";
	}
	@Test
	@Transactional
	@RequestMapping("/deleteloc")
	public String deleteloc(@RequestParam("token_id") Long token_id,ModelMap modelmap) {
		locserv.deleteByToken_id(token_id);
		List<loc>locweb= locserv.getalllocation();
		modelmap.addAttribute("locweb",locweb);	
		return "showlocation";
	}
	@RequestMapping("/updateloc")
	public String updateloc(@RequestParam("token_id") Long token_id,ModelMap modelmap) {
		loc findbyloc = locserv.findbyToken_id(token_id);
		modelmap.addAttribute("find",findbyloc);
		return "updatelocnew";
	}
	@RequestMapping("/updatelocdata")
	public String updatelocdata(locdto locdto,ModelMap modelmap){
		loc loc=new loc();
		loc.setId(locdto.getId());
		loc.setToken_id(locdto.getToken_id());
		loc.setName(locdto.getName());
		loc.setCode(locdto.getCode());
		loc.setType(locdto.getType());
		
		locserv.insertlocation(loc);
		List<loc>locweb= locserv.getalllocation();
		modelmap.addAttribute("locweb",locweb);	
		return "showlocation";
	}
}