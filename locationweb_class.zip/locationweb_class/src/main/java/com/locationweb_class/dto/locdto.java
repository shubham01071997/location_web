package com.locationweb_class.dto;

public class locdto {
	private long token_id;
	private long id;
	private String name;
	private String code;
	private String type;
	public long getToken_id() {
		return token_id;
	}
	public void setToken_id(long token_id) {
		this.token_id = token_id;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	

}
