package com.locationweb_class.services;

import java.util.List;

import com.locationweb_class.entity.loc;

public interface locservices {
	public List<loc> getalllocation();
	public void insertlocation(loc loc);
	public void deleteByToken_id(Long token_id);
	public loc findbyToken_id(Long token_id);
}
