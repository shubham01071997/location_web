package com.locationweb_class.services;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.locationweb_class.entity.loc;
import com.locationweb_class.repository.locrepository;

@Service
public class locservicesImpl implements locservices {
        @Autowired
        private locrepository locrepo;

		@Override
		public List<loc> getalllocation() {
			List<loc> locweb=locrepo.findAll();
			return locweb;
		}

		@Override
		public void insertlocation(loc loc) {
			locrepo.save(loc);
		}
		public void deleteByToken_id(Long token_id) {
			locrepo.deleteByToken_id(token_id);
			
		}

		@Override
		public loc findbyToken_id(Long token_id) {
			Optional<loc> findbyid=locrepo.findByToken_id(token_id);
			loc loc=findbyid.get();
			return loc;
		}
	
} 
