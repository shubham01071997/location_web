package com.locationweb_class.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.locationweb_class.entity.loc;
@Repository
public interface locrepository extends JpaRepository<loc,Long> {
	
	@Transactional
    @Modifying
	@Query("delete from loc where token_id=:token_id")
	void deleteByToken_id(Long token_id);
	
	@Transactional
	@Query("from loc where token_id=:token_id")
	Optional<loc> findByToken_id(Long token_id);
	
	
}
